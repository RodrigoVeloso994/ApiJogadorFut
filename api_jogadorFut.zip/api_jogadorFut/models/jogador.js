module.exports = (sequelize, DataTypes) => {
    const jogador = sequelize.define(
      {
        id: {
          type: Sequelize.INTEGER,
          autoIncrement: true,
          primaryKey: true
      },
      nome: {
          type: Sequelize.STRING,
          allowNull: false
      },
      idade: {
          type: Sequelize.INTEGER,
          allowNull: false
      },
      altura: {
          type: Sequelize.FLOAT,
          allowNull: false
      },
      clubeAtual: {
          type: Sequelize.STRING,
          allowNull: false
      },
      },
      {
        freezeTableName: true,
        tableName: 'jogadorFut',
        timestamps: true,
        createdAt: 'dataCriacao',
        updatedAt: 'dataAtualizacao',
        version: 'versao'
      }
    );
    return jogador;
  };
  