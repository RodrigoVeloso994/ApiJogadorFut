module.exports = {
  development: {
      database: 'db-9ln32y3hryhg',
      username: 'db-9ln32y3hryhg',
      password: 'M0vZlWrpe0qTmqYK591jaxLW',
      host: 'up-es-mad1-mysql-1.db.run-on-erla.com',
      port: '11550',
      dialect: 'mysql'
  },
};